
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Info</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Helvetica", sans-serif;
        }

        #filters {
            margin-left: 10%;
            margin-top: 2%;
            margin-bottom: 2%;
        }
    </style>
</head>
<body>
    <div id="filters">
        <span>Select how to sort &nbsp;</span>
        <select name="fetchval" id="fetchval">
            <option value="" disabled="" selected="">Select filter</option>
            <option value="">first_name</option>
            <option value="">Email</option>
            <option value="">created date</option>
        </select>
    </div>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Place Location</th>
                    <th>Token ID</th>
                    <th>Amount</th>
                    <th>Created Date</th>
                </tr>
            </thead>
            <tbody> 
                <?php $__currentLoopData = $paymentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($info->first_name); ?></td>
                    <td><?php echo e($info->last_name); ?></td>
                    <td><?php echo e($info->email); ?></td>
                    <td><?php echo e($info->phone_number); ?></td>
                    <td><?php echo e($info->place_location); ?></td>
                    <td><?php echo e($info->paid_token); ?></td>
                    <td><?php echo e($info->amount); ?></td>
                    <td><?php echo e($info->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script type="text/javascript">
    $(document).ready(function(){
        $("#fetchval").on('change',function(){
            var value=$(this).val();
            alert(value);
        })
        var
    });

    </script>
</body>
</html>
<?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/paymentInfo.blade.php ENDPATH**/ ?>