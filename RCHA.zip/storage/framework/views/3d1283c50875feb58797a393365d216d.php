


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paid Video View</title>
    
</head>
<body>
    <h1>Paid Video View</h1>
   
    <iframe src="http://www.youtube.com/embed/<?php echo e($token); ?>" class="btn btn-primary" style="width:100%; height:100%; border:none; overflow:auto; scrollbar-width: thin;" allowfullscreen>View Video</iframe>
    
            
</div>
</body>
</html> 

    
    
    
    
       
       
       
   
  <?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/videoView.blade.php ENDPATH**/ ?>