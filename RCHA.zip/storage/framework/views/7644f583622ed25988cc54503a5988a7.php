[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>