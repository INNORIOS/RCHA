<?php echo e($slot); ?>

<?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>