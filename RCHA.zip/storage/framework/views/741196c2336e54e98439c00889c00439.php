
<?php $__env->startSection('tile','paymentInfoExport'); ?>
<?php $__env->startSection('content'); ?>

<div>
    <h1>Download Test</h1>

    
        <form action="http://127.0.0.1:8000/api/auth/export-payment-info" method="GET">
        <button type="submit">Download Excel File</button>
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/paymentInfoExportView.blade.php ENDPATH**/ ?>