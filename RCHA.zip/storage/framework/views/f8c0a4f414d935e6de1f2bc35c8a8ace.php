<?php echo e($slot); ?>

<?php /**PATH C:\xampp\RCHA RESERVED\RCHA\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>