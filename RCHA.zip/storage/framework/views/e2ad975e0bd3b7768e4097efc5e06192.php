<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('paymentInfoExport'); ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css">
   <style> ::-webkit-scrollbar {
    display: none;
  }</style> 
</head>
<body>
    <div class="no-scrollbar">
    <div class="container mt-5">
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/layout-session.blade.php ENDPATH**/ ?>