<?php $__env->startComponent('mail::message'); ?>
# Welcome <?php echo e(Auth::user()->last_name); ?>!!


<?php $__env->startComponent('mail::button', ['url' => url("/api/auth/videoView/{$paidToken}")]); ?>
Click here to watch
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('mail::panel'); ?>
This is panel
<?php echo $__env->renderComponent(); ?>
Thanks <br>
RCHA
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\RCHA RESERVED\RCHA\resources\views/sendVideoLink/sendVideoLinkView.blade.php ENDPATH**/ ?>