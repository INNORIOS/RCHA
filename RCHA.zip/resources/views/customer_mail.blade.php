{{-- dear {{ $last_name['first_name'] }} <br/> 
	  thank you for ordering with us <br/>
		Thank you<br/> our contact detail as of below<br/> kathmandu nepal<br/>
		email : {{ $last_name['email'] }} --}}